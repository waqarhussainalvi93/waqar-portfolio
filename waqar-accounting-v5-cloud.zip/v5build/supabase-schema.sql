-- Waqar Accounting V5 Cloud schema
-- Run this in Supabase SQL Editor before enabling Cloud Setup.
-- Uses Supabase Auth for passwords. Never store passwords in public tables.

create extension if not exists pgcrypto;

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  workspace_id uuid references public.workspaces(id) on delete set null,
  role text not null default 'viewer' check (role in ('admin','accountant','sales','purchase','viewer')),
  created_at timestamptz not null default now()
);

create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'viewer' check (role in ('admin','accountant','sales','purchase','viewer')),
  created_at timestamptz not null default now(),
  primary key (workspace_id,user_id)
);

create table if not exists public.workspace_data (
  workspace_id uuid primary key references public.workspaces(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);

create index if not exists idx_profiles_workspace on public.profiles(workspace_id);
create index if not exists idx_members_user on public.workspace_members(user_id);

create or replace function public.is_workspace_member(wid uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.workspace_members m where m.workspace_id=wid and m.user_id=auth.uid());
$$;

create or replace function public.is_workspace_admin(wid uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.workspace_members m where m.workspace_id=wid and m.user_id=auth.uid() and m.role='admin');
$$;

create or replace function public.create_workspace(workspace_name text)
returns uuid language plpgsql security definer set search_path=public as $$
declare wid uuid;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  if exists(select 1 from public.profiles where id=auth.uid() and workspace_id is not null) then
    raise exception 'User already belongs to a workspace';
  end if;
  insert into public.workspaces(name) values (coalesce(nullif(trim(workspace_name),''),'My Business')) returning id into wid;
  insert into public.workspace_members(workspace_id,user_id,role) values(wid,auth.uid(),'admin');
  insert into public.profiles(id,email,full_name,workspace_id,role)
    values(auth.uid(),(select email from auth.users where id=auth.uid()),'',wid,'admin')
    on conflict(id) do update set workspace_id=excluded.workspace_id,role='admin';
  insert into public.workspace_data(workspace_id,data,updated_by) values(wid,'{}'::jsonb,auth.uid());
  return wid;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,email,full_name) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'full_name','')) on conflict(id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.workspaces enable row level security;
alter table public.profiles enable row level security;
alter table public.workspace_members enable row level security;
alter table public.workspace_data enable row level security;

drop policy if exists workspace_member_select on public.workspaces;
create policy workspace_member_select on public.workspaces for select using (public.is_workspace_member(id));

drop policy if exists profile_self_or_admin on public.profiles;
create policy profile_self_or_admin on public.profiles for select using (id=auth.uid() or (workspace_id is not null and public.is_workspace_admin(workspace_id)));

drop policy if exists members_select on public.workspace_members;
create policy members_select on public.workspace_members for select using (public.is_workspace_member(workspace_id));

drop policy if exists members_admin_update on public.workspace_members;
create policy members_admin_update on public.workspace_members for update using (public.is_workspace_admin(workspace_id)) with check (public.is_workspace_admin(workspace_id));

drop policy if exists data_member_all on public.workspace_data;
create policy data_member_all on public.workspace_data for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

-- Important: the browser must only use the project's Publishable Key.
-- Never expose a secret/service-role key in index.html.

-- Admin-only RPCs for safe user management from the browser.
create or replace function public.add_user_to_workspace(user_email text, new_role text)
returns void language plpgsql security definer set search_path=public as $$
declare target_id uuid; wid uuid;
begin
  select workspace_id into wid from public.profiles where id=auth.uid();
  if wid is null or not public.is_workspace_admin(wid) then raise exception 'Admin access required'; end if;
  if new_role not in ('admin','accountant','sales','purchase','viewer') then raise exception 'Invalid role'; end if;
  select id into target_id from auth.users where lower(email)=lower(trim(user_email));
  if target_id is null then raise exception 'No Auth user found for this email. Create the user in Authentication first.'; end if;
  insert into public.workspace_members(workspace_id,user_id,role) values(wid,target_id,new_role)
    on conflict(workspace_id,user_id) do update set role=excluded.role;
  update public.profiles set workspace_id=wid,role=new_role where id=target_id;
end; $$;

create or replace function public.set_member_role(target_user_id uuid, new_role text)
returns void language plpgsql security definer set search_path=public as $$
declare wid uuid;
begin
  select workspace_id into wid from public.profiles where id=auth.uid();
  if wid is null or not public.is_workspace_admin(wid) then raise exception 'Admin access required'; end if;
  if new_role not in ('admin','accountant','sales','purchase','viewer') then raise exception 'Invalid role'; end if;
  update public.workspace_members set role=new_role where workspace_id=wid and user_id=target_user_id;
  update public.profiles set role=new_role where id=target_user_id and workspace_id=wid;
end; $$;
